<template>
  
  <v-app  :style="'background-color :'+color+';'">
    <v-container v-if="view_on">
     <side   @onLogin="onLogin_2" :isLoginsub="isLogin" @logOut="outLog"/>
      <ImgBanner/>
      <router-view/>
      <Footer/>
      <RegisterBefore :dialog="onLoginModal" @onLogin="onLogin_2"/>
      <register-github-member :dialog="ifLogin" @onLogin="onLogin_3"></register-github-member>  
      <v-btn v-if="this.isLogin" bottom color="pink"  dark fab fixed right>
      <v-badge
          color="green"
          content="6"
      >
        <v-icon  color="white">mdi-email</v-icon>
      </v-badge>
    </v-btn>  
    </v-container>
    <v-container   v-else>
      <v-img src="https://mir-s3-cdn-cf.behance.net/project_modules/fs/bc90cc81411939.5d2f90e336b69.gif" style="max-width: 80vw; height: auto;"/>
    </v-container>
        
  </v-app>
</template>

<script>
import side from './components/side'
import ImgBanner from './components/ImgBanner'
import Footer from './components/seo/Footer'
import RegisterBefore from './components/yoon/RegisterBefore'
import RegisterGithubMember from './components/yoon/RegisterGithubMember'
import http from './http-common';
export default {
  name: 'App',
  components : {
    side,
    ImgBanner,
    Footer, 
    RegisterBefore,
    RegisterGithubMember,
    
  },
  data(){
    return {
      onLoginModal:false,
      isLogin:false,
      ifLogin : false,
      view_on : false,
      color : 'black',
    }
  },
  methods:{
    outLog(data){
      if(data){
        sessionStorage.setItem('x-access-token',null);
        this.isLogin = false;
        return this.callback();
      }
    },
    onLogin_2(data){
      console.log("!!!!!!!!!!!!!!!!!!!");
      if(sessionStorage.getItem('x-access-token')==null||sessionStorage.getItem('x-access-token')==undefined||sessionStorage.getItem('x-access-token')==""||sessionStorage.getItem('x-access-token')=="null"){
        this.isLogin = false;
        console.log("App.vue>>-----------this.isLogin = null >>");
      }else{
        this.isLogin = true;
        console.log("App.vue>>-----------this.isLogin Not null >>"+this.isLogin);
        console.log(sessionStorage.getItem('x-access-token'));
      }
      this.onLoginModal = data;
    },
    checkLogin(){
      let code = location.search.split('code=')[1];
      console.log("App.vue>>------checkLogin()-----"+code);
      http.post('/github/accessToken',{"code":code})
      .then(response=>{
        // console.log("??????????"+response.data);
        return this.isJWTNull(response.data);
      })
      .catch(err=>{
        console.log(err);
      });
      return this.isJWTNull(null);
    },
    isJWTNull(value){
      if(value!=null){
        sessionStorage.setItem('github-access-token',value.access_token);
      
      if(value.hasOwnProperty("access_token")&&(value.login_access_token==null||value.login_access_token===null||value.login_access_token=='null')){
        console.log(">>>>>>>>>>>>>"+value);
        return this.ifLogin=true;
      }else if(value.hasOwnProperty("access_token")){
          sessionStorage.setItem('x-access-token',value.login_access_token);
          http.defaults.headers.common['x-access-token'] = value.login_access_token;
          console.log("App.vue>>mounted()----"+sessionStorage.getItem('x-access-token'));
          console.log("App.vue>>mounted()----"+sessionStorage.getItem('github-access-token'));
          return this.callback();
      }
      }
    },
    callback(){
      if(sessionStorage.getItem('x-access-token')==null||
    sessionStorage.getItem('x-access-token')===undefined||
    sessionStorage.getItem('x-access-token')===""||
    sessionStorage.getItem('x-access-token')==="null"){
      this.isLogin = false;
    }else{
      this.isLogin = true;
    }
    console.log("App.vue>>------callback()----isLogin>>"+this.isLogin);
    console.log("App.vue>>-----callback()-----token>>"+sessionStorage.getItem('x-access-token'));
    },
    onLogin_3(){
      this.ifLogin = false;
    }
  },
  watch:{
        onLoginModal(){
          console.log("App.vue>>----------onLoginModal()>>"+this.onLoginModal);
        },
  },
  mounted(){
    
    let code = location.search.split('code=')[1];
    if(code!=null&&code!=""&&code!=undefined){
      this.checkLogin();
    }else{
      this.callback();
    }
    setTimeout(()=>{this.view_on=true; this.color = ""},2500);
  },


};
</script>
