<template>
    <div>
        uInfo
    </div>
</template>
<script>
export default {
    name:'uInfo',
}
</script>