<template>
    <div>
    </div>
</template>
<script>
export default {
    name:'hoInfo',
    props:{
        info:{type:String}
    }
}
</script>