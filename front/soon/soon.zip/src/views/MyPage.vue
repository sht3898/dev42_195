<template>
    <h1>MyPage</h1>
</template>

<script>
export default {
  name: 'HelloWorld',
  components : {
  },
  data(){
    return {
      modal : false,
      message : ''
    }
  },
  methods:{
    
  }
 
}
</script>


