<template>
    <h1>CreatePage</h1>
</template>

<script>

export default {
  name: 'CreatePage',
  components : {
   
  },
  data(){
    return {
      modal : false,
      message : ''
    }
  },
  methods:{
    
  }
 
}
</script>


